# ATASmileApi

To connect Smile One Api

step 0 -> You should have Merchant account for Smile One.<br>
step 1 -> Fill blanks in the ATAConfig_.py<br>
step 2 -> Rename ATAConfig_.py to ATAConfig.py<br>
step 3 -> That's all.<br>
